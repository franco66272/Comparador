from bs4 import BeautifulSoup
from urllib.parse import quote_plus
import json
import re
import time

from .utils import session_con_reintentos

API_URL = "https://www.maximus.com.ar/wfmWebSite2.aspx/wsNRW_Script"
PAGINA_SESION = "https://www.maximus.com.ar/Productos/Notebooks/maximus.aspx?/CAT=56/SCAT=-1/M=-1/OR=1/PAGE=1/"
BASE_URL = "https://www.maximus.com.ar"
GUID = "a632009a-7686-4fcb-a0b4-24b18caf5234"
HEADERS = {
    "Referer": PAGINA_SESION,
}

PAGE_DELAY = 0.5
MAX_PAGINAS = 60


def _precio(valor):
    if valor in (None, "", 0):
        return None

    try:
        n = float(valor)

        # Maximus devuelve algunos precios en escala /1000.
        # Ejemplo: 33 -> 33200 mediante el precio original.
        if 0 < n < 1000:
            n *= 1000

        return int(round(n))
    except (ValueError, TypeError):
        return None


def _precio_principal(item):
    precio = _precio(item.get("prli_price"))
    original = _precio(item.get("prli_price_original"))

    # Si el precio principal es claramente demasiado pequeño
    # frente al original, usar el original como precio real.
    if original and precio:
        if precio < original * 0.1:
            return original

    if precio and precio > 0:
        return precio

    return original


def _imagen(item):
    campos = (
        "item_img",
        "item_image",
        "img",
        "image",
        "item_img1",
        "item_picture",
        "picture",
    )

    for campo in campos:
        valor = item.get(campo)

        if not valor:
            continue

        valor = str(valor).strip()

        if valor.startswith("//"):
            return "https:" + valor

        if valor.startswith("/"):
            return BASE_URL + valor

        if valor.startswith("http://") or valor.startswith("https://"):
            return valor

    codigo = str(item.get("item_code4web") or "").strip()

    if codigo:
        return (
            f"{BASE_URL}/Temp/App_WebSite/App_PictureFiles/"
            f"Items/{codigo}.jpg"
        )

    return None


def _url_producto(item):
    item_id = item.get("item_id")
    nombre = item.get("item_desc") or item.get("item_desc4link")
    codigo = item.get("item_code4web")

    if not item_id or not nombre:
        return None

    slug = str(nombre).strip().replace(" ", "-")

    url = f"{BASE_URL}/Producto/{slug}/ITEM={item_id}/maximus.aspx"

    if codigo:
        url += f"?PN={codigo}"

    return url


def _llamar_api(session, pagina):
    params = {
        "ws_id": GUID,
        "comp_id": 1,
        "prli_id": 17,
        "cust_id": -1,
        "page": pagina,
        "cat_id": -1,
        "subcat_id": -1,
        "brand_id": -1,
        "local": 0,
        "search": "",
        "order": 1,
        "price_min": "",
        "price_max": "",
        "wco_tV": [],
    }

    body = {
        "guidWS_Id": GUID,
        "strScriptLabel": "web.MAX.GetItemList4Search_v3_V6",
        "JSonParameters": json.dumps(
            params,
            ensure_ascii=False,
        ),
    }

    headers = {
        "Content-Type": "application/json; charset=UTF-8",
        "Referer": PAGINA_SESION,
        "Origin": BASE_URL,
    }

    response = session.post(
        API_URL,
        json=body,
        headers=headers,
        timeout=30,
    )

    response.raise_for_status()

    data = response.json()
    contenido = data.get("d")

    if isinstance(contenido, str):

        texto = contenido.strip()

        # La API puede devolver HTTP 200 con un error de aplicación.
        if (
            texto.startswith("-2,")
            or "GlobalBluePoint" in texto
            or "GBPScripts" in texto
            or "NO ADQUIRIDO" in texto
        ):
            raise RuntimeError(
                f"API Maximus rechazó la consulta: {texto}"
            )

        try:
            contenido = json.loads(texto)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"Respuesta API Maximus no JSON: {texto[:300]}"
            ) from exc

    if not isinstance(contenido, dict):
        raise RuntimeError(
            "Respuesta API Maximus inesperada"
        )

    return contenido.get("data", {})

def _normalizar_nombre_imagen(texto):
    texto = str(texto or "").lower()

    texto = re.sub(
        r"[^a-z0-9áéíóúüñ]+",
        " ",
        texto,
    )

    return " ".join(texto.split())


def _imagen_desde_catalogo_web(
    session,
    nombre,
    cache,
):
    """
    Busca el producto en el catálogo web de Maximus
    y recupera la primera imagen asociada a la tarjeta
    cuyo nombre coincide suficientemente.
    """

    clave = _normalizar_nombre_imagen(nombre)

    if not clave:
        return None

    if clave in cache:
        return cache[clave]

    try:
        termino = quote_plus(str(nombre))

        url = (
            BASE_URL
            + "/Productos/maximus.aspx?"
            + "CAT=-1/SCAT=-1/M=-1/"
            + f"BUS={termino}/OR=1/PAGE=1/"
        )

        response = session.get(
            url,
            headers=HEADERS,
            timeout=30,
        )

        if response.status_code != 200:
            cache[clave] = None
            return None

        soup = BeautifulSoup(
            response.text,
            "html.parser",
        )

        objetivo = _normalizar_nombre_imagen(nombre)

        candidatos = []

        for contenedor in soup.select(
            "div, li, article"
        ):

            texto = _normalizar_nombre_imagen(
                contenedor.get_text(
                    " ",
                    strip=True,
                )
            )

            if not texto:
                continue

            # Coincidencia fuerte por nombre completo.
            if objetivo not in texto:
                continue

            for img in contenedor.find_all("img"):

                atributos = (
                    img.get("src"),
                    img.get("data-src"),
                    img.get("data-lazy-src"),
                    img.get("data-original"),
                    img.get("data-image"),
                )

                for imagen in atributos:

                    if not imagen:
                        continue

                    imagen = str(imagen).strip()

                    if imagen.startswith("//"):
                        imagen = "https:" + imagen

                    elif imagen.startswith("/"):
                        imagen = BASE_URL + imagen

                    if (
                        imagen.startswith("http://")
                        or imagen.startswith("https://")
                    ):
                        candidatos.append(imagen)

        # Si encontramos imágenes dentro de la tarjeta
        # coincidente, descartar logos/iconos obvios.
        for imagen in candidatos:

            lower = imagen.lower()

            if any(
                x in lower
                for x in (
                    "logo",
                    "favicon",
                    "mercadopago",
                    "whatsapp",
                    "stock",
                    "garantia",
                    "envio",
                )
            ):
                continue

            cache[clave] = imagen
            return imagen

    except Exception:
        pass

    cache[clave] = None
    return None



def _parsear_item(
    item,
    session=None,
    imagen_cache=None,
):
    nombre = item.get("item_desc")
    item_id = item.get("item_id")
    codigo = item.get("item_code4web")

    precio = _precio_principal(item)
    precio_original = _precio(
        item.get("prli_price_original")
    )

    if not nombre or not item_id or not precio or precio <= 0:
        return None

    if precio_original and precio_original <= precio:
        precio_original = None

    url = _url_producto(item)

    if not url:
        return None

    imagen = _imagen(item)

    # Segunda capa: catálogo web de Maximus.
    if (
        not imagen
        and session is not None
    ):
        if imagen_cache is None:
            imagen_cache = {}

        imagen = _imagen_desde_catalogo_web(
            session,
            nombre,
            imagen_cache,
        )

    identificador = (
        f"{item_id}_{codigo}"
        if codigo
        else url
    )

    return {
        "tienda": "Maximus",
        "nombre": str(nombre).strip(),
        "precio": precio,
        "precio_anterior": precio_original,
        "stock": 1,
        "imagen": imagen,
        "url": url,
        "id_producto": identificador,
    }

def extraer():
    imagen_cache = {}
    session = session_con_reintentos()

    warnings = []
    productos = []
    ids_vistos = set()

    session.get(PAGINA_SESION, timeout=30)

    primera = _llamar_api(session, 1)

    paginas_total = int(primera.get("pagesTotal") or 1)
    total_reportado = int(primera.get("itemsTotal") or 0)

    paginas_total = min(paginas_total, MAX_PAGINAS)

    print(
        f"[maximus] API: {total_reportado} productos, "
        f"{paginas_total} páginas"
    )

    def procesar(items):
        nuevos = 0

        for item in items:
            producto = _parsear_item(item, session, imagen_cache)

            if not producto:
                continue

            identificador = producto["id_producto"]

            if identificador in ids_vistos:
                continue

            ids_vistos.add(identificador)
            productos.append(producto)
            nuevos += 1

        return nuevos

    procesar(primera.get("items") or [])

    for pagina in range(2, paginas_total + 1):
        time.sleep(PAGE_DELAY)

        try:
            data = _llamar_api(session, pagina)
        except Exception as exc:
            warnings.append(
                f"Error página {pagina}: {exc}"
            )
            break

        items = data.get("items") or []

        if not items:
            warnings.append(
                f"Página {pagina} sin productos"
            )
            break

        procesar(items)

        print(
            f"[maximus] página {pagina}/{paginas_total}: "
            f"{len(items)} items, "
            f"{len(productos)} acumulados"
        )

    if total_reportado:
        if len(productos) != total_reportado:
            warnings.append(
                f"API informa {total_reportado}, "
                f"se conservaron {len(productos)}"
            )

    precios_bajos = [
        p for p in productos
        if p["precio"] < 1000
    ]

    if precios_bajos:
        warnings.append(
            f"{len(precios_bajos)} precios menores a $1000"
        )

    con_imagen = sum(
        1 for p in productos
        if p.get("imagen")
    )

    return {
        "ok": len(productos) > 0,
        "tienda": "Maximus",
        "productos": productos,
        "con_imagen": con_imagen,
        "paginas_recorridas": paginas_total,
        "warnings": warnings,
    }


if __name__ == "__main__":
    resultado = extraer()

    print()
    print("=" * 50)
    print("MAXIMUS")
    print("=" * 50)
    print(f"OK: {resultado['ok']}")
    print(f"Productos: {len(resultado['productos'])}")
    print(f"Con imagen: {resultado['con_imagen']}")
    print(f"Páginas: {resultado['paginas_recorridas']}")

    for warning in resultado["warnings"]:
        print(f"WARNING: {warning}")

    if resultado["productos"]:
        print()
        print("Ejemplo:")
        print(resultado["productos"][0])

