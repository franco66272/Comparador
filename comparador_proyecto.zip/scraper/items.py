# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from dataclasses import dataclass


@dataclass
class ScraperItem:
    # define the fields for your item here like:
    # name: str | None = None
    pass
